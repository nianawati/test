<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kategoris extends Model
{
    protected $fillable = ['id_bunga','jumlah_bunga_dijual'];
}
